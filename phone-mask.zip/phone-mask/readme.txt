Connect css files:
	<link rel="stylesheet" type="text/css" href="refereces/intl-tel-input-master/build/css/intlTelInput.css">

Connect js files:
	<script src="references/jquery.min.js"></script>
	<script src="refereces/intl-tel-input-master/build/js/intlTelInput.js"></script>
        <script src="refereces/intl-tel-input-master/build/js/utils.js"></script>
        <script src="refereces/jquery.mask.js"></script>
        <script src="src/init-phone-country-list.js"></script>


Example:
	<input type="text" id="user_phone" name="phone" placeholder="Телефон" class="form-control" autocomplete="off" maxlength="15">


	// Set default selected and preferred country (preferred countries ['ru', 'us', ...])
	$('#user_phone').intlTelInput({
		defaultCountry: "ru",
		preferredCountries: ['ru']
	});

	// Set default country code in input
	$("#user_phone").val('+' + $("#user_phone").intlTelInput("getSelectedCountryData").dialCode);

	// Detect on change country from list and use the country's mask to enter phone
	$('.country').on('click', function () {
		$("#user_phone").val('');
		$("#user_phone").val('+' + $(this).attr('data-dial-code'));
		$("#user_phone").mask(countryPhoneMasks[$(this).attr('data-country-code')].mask);
	});

	// By default set mask
	$("#user_phone").mask(countryPhoneMasks[$("#user_phone").intlTelInput("getSelectedCountryData").iso2].mask);

	// Detect if change flag (Example if remove all from input and start enter with hands) set mask
	$("#user_phone").on("countrychange", function(e, countryData) {
		if (countryData.iso2 !== undefined) {
		    $("#user_phone").mask(countryPhoneMasks[countryData.iso2].mask);
		}
	});

       // Regular expression on checking correct entered "phone"
       $('#user_phone').on('blur', function (event) {
           var regex = /^(?=.*[0-9])[-+()0-9]+$/;
           var mask = countryPhoneMasks[$(this).intlTelInput("getSelectedCountryData").iso2].mask;

           if(regex.test($(this).val()) && isValidPhone($(this).val(), mask)) {
               console.log('phone number is correct');
           } else {
	       console.log('phone number is incorrect');
           }
       });
